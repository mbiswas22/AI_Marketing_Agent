import json
 
def api_response(
    status_code,
    body
):
 
    return {
 
        "statusCode":
            status_code,
 
        "headers": {
 
            "Access-Control-Allow-Origin":
                "*",
 
            "Access-Control-Allow-Headers":
                "*",
 
            "Access-Control-Allow-Methods":
                "*",
 
            "Content-Type":
                "application/json"
        },
 
        "body":
            json.dumps(
                body,
                default=str
            )
    }

def require_role(
    user,
    allowed_roles
):
 
    role = user.get("role")
 
    if role not in allowed_roles:
 
        raise Exception(
            "Unauthorized"
        )

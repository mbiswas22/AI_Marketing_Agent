def get_user(event):

    claims = (
        event["requestContext"]
        ["authorizer"]
        ["jwt"]
        ["claims"]
    )

    return {
        "user_id": claims.get("sub"),
        "email": claims.get("email"),
        "business_id": claims.get("custom:businessId"),
        "role": claims.get("custom:role", "VIEWER")
    }